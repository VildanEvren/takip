,<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1254" />

        <title>Personel Takip</title>

        <link rel="stylesheet" href="css/reset.css" type="text/css" media="screen" />

        <link rel="stylesheet" href="css/style.css" type="text/css" media="screen" />

        <link rel="stylesheet" href="css/invalid.css" type="text/css" media="screen" />	

        <script type="text/javascript" src="scripts/jquery-1.3.2.min.js"></script>

        <script type="text/javascript" src="scripts/simpla.jquery.configuration.js" ></script>

        <script type="text/javascript" src="scripts/facebox.js" ></script>

        <script type="text/javascript" src="scripts/jquery.wysiwyg.js" ></script>

        <script type="text/javascript" src="scripts/jquery.datePicker.js"></script>
        <script type="text/javascript" src="scripts/jquery.date.js"></script>



    </head>

    <body><div id="body-wrapper"> 