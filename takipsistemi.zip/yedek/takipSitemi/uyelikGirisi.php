<!DOCTYPE html>

<html lang="en">
    <head>
    <title>Personel Takip</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <style>
            /* Remove the navbar's default rounded borders and increase the bottom margin */
            .navbar {
                margin-bottom: 50px;
                border-radius: 0;
            }

            /* Remove the jumbotron's default bottom margin */
            .jumbotron {
                margin-bottom: 0;
            }

            /* Add a gray background color and some padding to the footer */
            footer {
                background-color: #f2f2f2;
                padding: 25px;
            }
        </style>
    </head>
    <body>
    <div class="jumbotron">
        <div class="container text-center">
            <h1>
                AKINSOFT	
            </h1>
            <p>Personel Girişi</p>
        </div>
    </div>

    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>


                </nav> 


                <div class="container">
                    <div class="row">


                        <div class="col-lg-4">
                            <div class="panel panel-danger">
                                <div class="panel-heading"><font color='#990066' size='3'>Personel Girişi</font></div>
                                <form action="uyeLogin.php" method="POST" >
                                    <table align="center">
                                        <tr> <br> </tr>

                                        <tr>
                                            <td><font color='#990066'>Personel Adı</font></td>
                                            <td><font color='#990066'>:&nbsp;&nbsp;</td>
                                            <td><input autocomplete="off" required class="form-control" placeholder="Personel adı..." type="text" name="kullanici_adi"></td>
                                            </tr>

                                            <tr> 
                                                <td> <br> </td>
                                            </tr>

                                            <tr>
                                                <td><font color='#990066'>Sifre</font></td>
                                                <td><font color='#990066'>:&nbsp;&nbsp;</td>
                                                <td><input autocomplete="off" required class="form-control" placeholder="Personel şifresi..." type="password" name="sifre"></td>
                                                </tr>

                                                <tr> 
                                                    <td> <br> </td>
                                                </tr>

                                                <tr>
                                                    <td></td>
                                                    <td></td>

                                                    <td>
                                                        <button type="submit" class="btn btn-success">Personel Girişi</button>
                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                        <button type="reset" class="btn btn-info">Temizle</button>
                                                </tr>

                                                <tr>
                                                    <td> <br> </td>
                                                </tr>

                                                </table>
                                                </form>
                                                <div class="panel-footer"></div>
                                                </div>
                                                </div>

                                                </div>
                                                </div><br>


                                                </body>
                                                </html>

