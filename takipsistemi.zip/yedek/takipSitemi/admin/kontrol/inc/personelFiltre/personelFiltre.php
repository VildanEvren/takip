
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<script src="scripts/jquery.tagsinput.min.js"></script>
<link rel="stylesheet" href="css/jquery.tagsinput.css" />
<script>
    $(document).ready(function () {
        $('.tagsinput').tagsInput({width: 'auto', height: 'auto'});
    });
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
header('Content-Type: text/html; charset=utf-8');
Connect();
header('Content-Type: text/html; charset=utf-8');
if (@get("islem") == "sil") {
    $sil = Sor("DELETE FROM personeller WHERE ID='" . @get("ID") . "'");
}
if (@$_POST) {
    $personel_TC = @mysql_real_escape_string(post("personel_TC"));
    $kullanici_adi = @mysql_real_escape_string(post("kullanici_adi"));
    $sifre = @mysql_real_escape_string(post("sifre"));
    $personel_adi = @mysql_real_escape_string(post("personel_adi"));
    $personel_soyadi = @mysql_real_escape_string(post("personel_soyadi"));
    $dogum_tarihi = @mysql_real_escape_string(post("dogum_tarihi"));
    $personel_cinsiyet = @mysql_real_escape_string(post("personel_cinsiyet"));
    $personel_adres = @mysql_real_escape_string(post("personel_adres"));
    $personel_il = @mysql_real_escape_string(post("personel_il"));
    $personel_ilce = @mysql_real_escape_string(post("personel_ilce"));
    $personel_tel = @mysql_real_escape_string(post("personel_tel"));

    if ($personel_TC == "") {
        echo '<br><br><br><br><br><br><br><br><br>';
        //mesajUyari('' , 'Personel TC\'sini bo� b�rakmay�n�z...');
    } else {
        if (@get("islem") == "Ekle") {
            $Ekle = Sor("INSERT INTO personeller SET "
                    . "personel_TC='{$personel_TC}',"
                    . "kullanici_adi='{$kullanici_adi}',"
                    . "sifre='{$sifre}',"
                    . "personel_adi='{$personel_adi}',"
                    . "personel_soyadi='{$personel_soyadi}',"
                    . "dogum_tarihi='{$dogum_tarihi}',"
                    . "personel_cinsiyet='{$personel_cinsiyet}', "
                    . "personel_adres='{$personel_adres}',"
                    . "personel_il='{$personel_il}',"
                    . "personel_ilce='{$personel_ilce}',"
                    . "personel_tel='{$personel_tel}' 
				  ");



            if ($Ekle) {
                echo "<br><br><br><br><br><br><br><br><br>";
               mesajUyari('ok' , 'Basarili');
            } else {
                echo "<br><br><br><br><br><br><br><br><br>";
                mesajUyari('' , 'Yapilamadi');
            }
        } else if (@get("islem") == "Guncelle") {
            $Guncelle = Sor("UPDATE personeller SET "
                    . "personel_TC='{$personel_TC}',"
                    . "kullanici_adi='{$kullanici_adi}',"
                    . "sifre='{$sifre}',"
                    . "personel_adi='{$personel_adi}',"
                    . "personel_soyadi='{$personel_soyadi}',"
                    . "dogum_tarihi='{$dogum_tarihi}',"
                    . "personel_cinsiyet='{$personel_cinsiyet}', "
                    . "personel_adres='{$personel_adres}',"
                    . "personel_ilce='{$personel_ilce}',"
                    . "personel_tel='{$personel_tel}', "
                    . "personel_tel='{$personel_tel}'  "
                    . "WHERE ID='" . @get("ID") . "' ");



            if ($Guncelle) {
                echo "<br><br><br><br><br><br><br><br><br>";
                 mesajUyari('ok' , 'Basarili');
            } else {
                echo "<br><br><br><br><br><br><br><br><br>";
                mesajUyari('' , 'Yapilamadi');
            }
        }
    }
}

$num = $_POST['num'];
$isme = $_POST['isme'];
$soyisme = $_POST['soyisme'];
$tcye = $_POST['tcye'];
$secilencombo = $_POST["combo"];
$secilencombo1 = $_POST["combo1"];
$secilencombo2 = $_POST["combo2"];
$secilencombo3 = $_POST["combo3"];
$secilenradio = $_POST['optradio'];

//$KatSor = Sor("SELECT * FROM personeller ORDER BY ID ASC");

if (isset($_POST['kriter'])) {
    $sira = "";
    if ($secilenradio == "artan")
        $sira = "ASC";
    else
        $sira = "DESC";

    $KatSor = Sor("SELECT * FROM personeller ORDER BY " . $secilencombo . " " . $sira);
}


if (isset($_POST['say'])) {
    $KatSor = Sor("SELECT * FROM personeller ORDER BY ID ASC LIMIT 0, " . $num);
}


if (isset($_POST['adkriter'])) {
    $KatSor = Sor("SELECT * FROM personeller WHERE personel_adi='" . $isme . "' and personel_soyadi='" . $soyisme . "'");
}

if (isset($_POST['tcYe'])) {
    $KatSor = Sor("SELECT * FROM personeller WHERE personel_TC='" . $tcye . "'");
}


if (isset($_POST['tum'])) {
    $KatSor = Sor("select * from personeller where personel_adi='" . $isme . "' and personel_soyadi='" . $soyisme . "' and personel_TC='" . $tcye . "' 
	ORDER BY ID ASC LIMIT 0, " . $num);
}


if(isset($_POST['sec1']))
{
if($_POST['combo1'])
{
	$secilencombo1 = $_POST["combo1"];
	$isme = $_POST["isme"];
	
	
	if($secilencombo1== 'LIKE %'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_adi LIKE '".$isme."%' ");
		}
	
	else if($secilencombo1== 'NOT LIKE %'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_adi NOT LIKE '".$isme."%' ");
		}
		
		else if($secilencombo1== 'LIKE %%'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_adi  LIKE '%".$isme."%' ");
		}
		
		else if($secilencombo1== 'NOT LIKE %%'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_adi NOT LIKE '%".$isme."%' ");
		}
		
	    else if($secilencombo1== '>'){
		$KatSor = Sor("SELECT * FROM personeller  ORDER BY personel_adi ASC");
		}
		else if($secilencombo1== '<'){
		$KatSor = Sor("SELECT * FROM personeller  ORDER BY personel_adi DESC");
		}
		
}
}

if(isset($_POST['sec2']))
{
if($_POST['combo2'])
{
	$secilencombo2 = $_POST["combo2"];
	$tcye = $_POST['tcye'];
	
	
	if($secilencombo2== 'LIKE %'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_soyadi LIKE '".$tcye."%' ");
		}
	
	else if($secilencombo2== 'NOT LIKE %'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_soyadi NOT LIKE '".$tcye."%' ");
		}
		
		else if($secilencombo2== 'LIKE %%'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_soyadi  LIKE '%".$tcye."%' ");
		}
		
		else if($secilencombo2== 'NOT LIKE %%'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_soyadi NOT LIKE '%".$tcye."%' ");
		}
		
	    else if($secilencombo2== '>'){
		$KatSor = Sor("SELECT * FROM personeller  ORDER BY personel_soyadi ASC");
		}
		else if($secilencombo2== '<'){
		$KatSor = Sor("SELECT * FROM personeller  ORDER BY personel_soyadi DESC");
		}
		
}
}


if(isset($_POST['sec3']))
{
if($_POST['combo3'])
{
	$secilencombo3 = $_POST["combo3"];
	$soyisme = $_POST['soyisme'];
	
	
	if($secilencombo3== 'LIKE %'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_TC LIKE '".$soyisme."%' ");
		}
	
	else if($secilencombo3== 'NOT LIKE %'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_TC NOT LIKE '".$soyisme."%' ");
		}
		
		else if($secilencombo3== 'LIKE %%'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_TC  LIKE '%".$soyisme."%' ");
		}
		
		else if($secilencombo3== 'NOT LIKE %%'){
		$KatSor = Sor("SELECT * FROM personeller  where personel_TC NOT LIKE '%".$soyisme."%' ");
		}
		
	    else if($secilencombo3== '>'){
		$KatSor = Sor("SELECT * FROM personeller  ORDER BY personel_TC ASC");
		}
		else if($secilencombo3== '<'){
		$KatSor = Sor("SELECT * FROM personeller  ORDER BY personel_TC DESC");
		}
		
}
}

$where = array();
$where2 = array();
if ($_POST['isme']) {
    $isim = $_POST['isme'];
    array_push($where, "personel_adi='" . $isim . "'");
}
if ($_POST['soyisme']) {
    $syisim = $_POST['soyisme'];
    array_push($where, "personel_soyadi='" . $syisim . "'");
}
if ($_POST['tcye']) {
    $tcye = $_POST['tcye'];
    array_push($where, "personel_TC='" . $tcye . "'");
}



if ($_POST['optradio']) {
    $secilenradio = $_POST['optradio'];

    $secilencombo = $_POST["combo"];
    $sira = "";
    if ($secilenradio == "artan") {
        $sira = "ASC";
        array_push($where2, " ORDER BY " . $secilencombo . " " . $sira);
    } else {

        $sira = "DESC";
        array_push($where2, " ORDER BY " . $secilencombo . " " . $sira);
    }
}
if ($_POST['num']) {
    $num = $_POST['num'];
    array_push($where2, " LIMIT 0, " . $num);
}


if ($_POST['tum']) {
    $srg = implode(" AND ", $where);
    $srg2 = implode(" ", $where2);
    $KatSor = Sor("select * from personeller where " . $srg . " " . $srg2);
}



?>
</br></br></br></br></br></br></br></br></br></br>
<div class="content-box ">

    <div class="content-box-header"> <!-- Add the class "closed" to the Content box header to have it closed by default -->

        <h3>Personel Filtreleme</h3>

    </div> <!-- End .content-box-header -->

    <div class="content-box-content">

        <div class="tab-content default-tab">
<?php
if ((@get("islem") == "Duzenle" || @get("islem") == "Guncelle" ) AND @ get("ID") != "") {
    $OgrDuzenleSor = Sor("SELECT * FROM personeller WHERE ID='" . @get("ID") . "'");
    if (Sar($OgrDuzenleSor) > 0) {
        $OgrDuzenleYaz = Yaz($OgrDuzenleSor);
        ?>


                    <form action="index.php?Go=PersonelFiltre&islem=Guncelle&ID=<?php echo get("ID"); ?>" method="POST">

                        <fieldset>
                            <table class="table">

                                <tr>
                                    <td class="TableBaslik">Personel TC</td>
                                    <td class="TableContent"><input type="text" id="personel_TC" name="personel_TC" class="text-input large-input FontSize_13" value="<?php echo @post("personel_TC") != "" ? @post("personel_TC") : $OgrDuzenleYaz["personel_TC"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Kullanici Adi</td>
                                    <td class="TableContent"><input type="text" id="kullanici_adi" name="kullanici_adi" class="text-input large-input FontSize_13" value="<?php echo @post("personel_adi") != "" ? @post("personel_adi") : $OgrDuzenleYaz["personel_adi"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Sifre</td>
                                    <td class="TableContent"><input type="text" id="sifre" name="sifre" class="text-input large-input FontSize_13" value="<?php echo @post("personel_soyadi") != "" ? @post("personel_soyadi") : $OgrDuzenleYaz["personel_soyadi"]; ?>" /></td>
                                </tr>


                                <tr>
                                    <td class="TableBaslik">Personel Adi</td>
                                    <td class="TableContent"><input type="text" id="personel_adi" name="personel_adi" class="text-input large-input FontSize_13" value="<?php echo @post("personel_adi") != "" ? @post("personel_adi") : $OgrDuzenleYaz["personel_adi"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Personel Soyadi</td>
                                    <td class="TableContent"><input type="text" id="personel_soyadi" name="personel_soyadi" class="text-input large-input FontSize_13" value="<?php echo @post("personel_soyadi") != "" ? @post("personel_soyadi") : $OgrDuzenleYaz["personel_soyadi"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Personel Dogum Tarihi</td>
                                    <td class="TableContent"><input type="date" id="dogum_tarihi" name="dogum_tarihi" class="text-input large-input FontSize_13" value="<?php echo @post("dogum_tarihi") != "" ? @post("dogum_tarihi") : $OgrDuzenleYaz["dogum_tarihi"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Personel Cinsiyeti</td>
                                    <td class="TableContent"><input type="text" id="personel_cinsiyet" name="personel_cinsiyet" class="text-input large-input FontSize_13" value="<?php echo @post("personel_cinsiyet") != "" ? @post("personel_cinsiyet") : $OgrDuzenleYaz["personel_cinsiyet"]; ?>" /></td>
                                </tr>


                                <tr>
                                    <td class="TableBaslik">personel Adres</td>
                                    <td class="TableContent"><input type="text" id="personel_adres" name="personel_adres" class="text-input large-input FontSize_13" value="<?php echo @post("personel_adres") != "" ? @post("personel_adres") : $OgrDuzenleYaz["personel_adres"]; ?>" /></td>
                                </tr>
                                <tr>
                                    <td class="TableBaslik">Il</td>
                                    <td class="TableContent"><input type="text" id="personel_il" name="personel_il" class="text-input large-input FontSize_13" value="<?php echo @post("personel_il") != "" ? @post("personel_il") : $OgrDuzenleYaz["personel_il"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Ile</td>
                                    <td class="TableContent"><input type="text" id="personel_ilce" name="personel_ilce" class="text-input large-input FontSize_13" value="<?php echo @post("personel_ilce") != "" ? @post("personel_ilce") : $OgrDuzenleYaz["personel_ilce"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Telefon1</td>
                                    <td class="TableContent"><input type="text" id="personel_tel" name="personel_tel" class="text-input large-input FontSize_13" value="<?php echo @post("personel_tel") != "" ? @post("personel_tel") : $OgrDuzenleYaz["personel_tel"]; ?>" /></td>
                                </tr>



                                <tr>
                                    <td class="TableBaslik"></td>
                                    <td class="TableContent"><input type="submit" id="kaydet" name="kaydet" class="button MarginR_15 FontSize_15" value="Kaydet" />
                                <a href="index.php?Go=PersonelFiltre" class="remove-link FontSize_14">iptal et </a></td>
                                </tr>


                            </table>
                        </fieldset>
                    </form>



        <?php
    } else {
        mesajUyari('', 'B�yle bir kay�t yok');
    }
} else if (@get("islem") == "") {
    ?>
                <form action="index.php?Go=PersonelFiltre&islem=Ekle" method="POST">

                    <fieldset>
                        <table class="table">

                            <tr> 
                                <td style="width:5%"></td>
                                <td>

                                    <table>
                                        <tbody>
                                            <tr>
                                                <td style="width:20%">
                                        <center>
                                            <select data-style="btn-primary" class="selectpicker" data-live-search="true" name="combo">
                                                <option>siralama kriteri sec</option>
                                                <option>ID</option>
                                                <option>personel_TC</option>
                                                <option>personel_adi</option>
                                                <option>personel_soyadi</option>
                                                <option>dogum_tarihi</option>
                                                <option>kullanici_adi</option>
                                            </select>
                                        </center>
                                        <br>
                                        <label><input type="radio" id="az" name="optradio" value="azalan">Azalan Sirada</label>
                                        <label><input type="radio" name="optradio" value="artan">Artan Sirada</label>
                                        <input type="submit" id="kriter" name="kriter" value="Siralama KRITERI" /></td>
                                </td>


						<td>
						 <table>
						  <tr>
						    <td>Adi:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  type="text" placeholder="personel adi..." class="text-input Default-input" id="isme" name="isme">
											 <select data-style="btn-primary" class="selectpicker" data-live-search="true" name="combo1">
                                              
                                                <option><</option>
                                                <option>></option>
                                                <option>LIKE %</option>
												 <option>NOT LIKE %</option>
                                                <option>LIKE %%</option>
                                                <option>NOT LIKE %%</option>
                                                

                                            </select>
											
											</td>
						  </tr>
						  
						   <tr>
						    <td>Soyadi:<input  type="text" placeholder="personel soyadi..." class="text-input Default-input" id="soyisme" name="soyisme">
								 <select data-style="btn-primary" class="selectpicker" data-live-search="true" name="combo2">
                                               
                                                <option><</option>
                                                <option>></option>
                                                <option>LIKE %</option>
												 <option>NOT LIKE %</option>
                                                <option>LIKE %%</option>
                                                <option>NOT LIKE %%</option>
                                            </select></td>
						  </tr>
						  
						   <tr>
						    <td>TC:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  type="text"placeholder="personel TC..."  id="tcye" class="text-input Default-input" name="tcye">
							 <select data-style="btn-primary" class="selectpicker" data-live-search="true" name="combo3">
                                                
                                                <option><</option>
                                                <option>></option>
                                                <option>LIKE %</option>
												 <option>NOT LIKE %</option>
                                                <option>LIKE %%</option>
                                                <option>NOT LIKE %%</option>
                                            </select></td>
						  </tr>
						 </table>
						</td>
						
						<td>
                            <table>
							
                              <tr>
								<td> 
								  <input type="submit" id="sec1" name="sec1" class="button MarginR_15 FontSize_15" value="&nbsp;&nbsp;&nbsp;Isme Gore&nbsp;&nbsp;" />
								</td>		
							   </tr>
							   
							   <tr>
							     <td class="TableContent">
								   <input type="submit" id="sec2" name="sec2" class="button MarginR_15 FontSize_15" value="Soyisme Gore" />
							     </td>
							   </tr>
									
							<tr>
							   <td class="TableContent">
							      <input type="submit" id="sec3" name="sec3" class="button MarginR_15 FontSize_15" value="&nbsp;&nbsp;TC ye Gore&nbsp;&nbsp;" />
							   </td>
                            </tr>
							
							</table>
                        </td>
						
                            </tr>
                            </tbody>
                            </table>

                            <tr>
                              <td> </td>
                                <td>
                                  <table>
                                   <tbody>
                                     <th>
                                      Kayit sayisi:<input type="number" class="text-input Default-input" min="0" max="20" value="0" class="form-control bfh-number" name="num">
                                      <input type="submit" id="tum" name="tum" class="button MarginR_15 FontSize_15" value="Verilere gore Filtrele" />
									</th>
                                 </table>
                                </td>
                           </tr>
                        </table>
                    </fieldset>
                </form>
<?php } ?>
        </div> <!-- End #tab3 -->        

    </div> <!-- End .content-box-content -->
    <div class="content-box-content">

        <div class="tab-content default-tab">

<?php
header('Content-Type: text/html; charset=utf-8');
if ($_POST['tum'] || $_POST['kriter'] || $_POST['sec1'] || $_POST['sec2'] || $_POST['sec3'] ) {
    if (@Sar($KatSor) > 0) {
        echo '<table class="table">'
        . '<tr>'
        . '<td style="width:25px;text-align:center;">NO</td>'
        . '<td>personel_TC</td>'
        . '<td>kullanici_adi</td>'
        . '<td>sifre</td>'
        . '<td>personel_adi</td>'
        . '<td>personel_soyadi</td>'
        . '<td>dogum_tarihi</td>'
        . '<td>personel_cinsiyet</td>'
        . '<td>personel_adres</td>'
        . '<td>personel_il</td>'
        . '<td>personel_ilce</td>'
        . '<td>personel_tel</td>'
        . '<td style="text-align:center;">Kontroller</td>'
        . '</tr>';
        while ($Yaz = @Yaz($KatSor)) {
            echo '<tr>'
            . '<td style="text-align:center;">' . $Yaz["ID"] . '</td>'
            . '<td style="text-align:center;">' . $Yaz["personel_TC"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["personel_adi"] . '</td>'
            . '<td style="text-align:center;">' . $Yaz["sifre"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["personel_adi"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["personel_soyadi"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["dogum_tarihi"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["personel_cinsiyet"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["personel_adres"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["personel_il"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["personel_ilce"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["personel_tel"] . '</td>'
            . '<td style="text-align:center;">'
            . '<a href="index.php?Go=PersonelFiltre&islem=Duzenle&ID=' . $Yaz["ID"] . '" title="D�zenle">Duzenle</a> | '
            . '<a href="index.php?Go=PersonelFiltre&islem=sil&ID=' . $Yaz["ID"] . '" title="sil" style="color:darkred;" onclick="return confirm(\'Silmek �stedi�inize Eminmisniz\')">sil</a>'
            . '</td>'
            . '</tr>';
        }
        echo '</table>';
    } else {
        echo 'Kayit Bulunamadi.';
    }
}
?>

        </div>
    </div>    
</div>


