<div id="footer">
    <small> <!-- Remove this notice or replace it with whatever you want -->
        &#169; Personel Takip 2016 | <a href="http://www.safakara.com">Vildan EVREN</a>.
    </small>
</div><!-- End #footer -->

</div> <!-- End #main-content -->

</div></body>

</html>
