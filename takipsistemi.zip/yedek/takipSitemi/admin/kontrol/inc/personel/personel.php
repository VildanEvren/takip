  
<script src="scripts/jquery.tagsinput.min.js"></script>
<link rel="stylesheet" href="css/jquery.tagsinput.css" />
<script>
    $(document).ready(function () {
        $('.tagsinput').tagsInput({width: 'auto', height: 'auto'});
    });
</script>

<?php
Connect();
if (@get("islem") == "sil") {
    $sil = Sor("DELETE FROM personeller WHERE ID='" . @get("ID") . "'");
}
if (@$_POST) {
    $personel_TC = @mysql_real_escape_string(post("personel_TC"));
    $kullanici_adi = @mysql_real_escape_string(post("kullanici_adi"));
    $sifre = @mysql_real_escape_string(post("sifre"));
    $personel_adi = @mysql_real_escape_string(post("personel_adi"));
    $personel_soyadi = @mysql_real_escape_string(post("personel_soyadi"));
    $dogum_tarihi = @mysql_real_escape_string(post("dogum_tarihi"));
    $personel_cinsiyet = @mysql_real_escape_string(post("personel_cinsiyet"));
    $personel_adres = @mysql_real_escape_string(post("personel_adres"));
    $personel_il = @mysql_real_escape_string(post("personel_il"));
    $personel_ilce = @mysql_real_escape_string(post("personel_ilce"));
    $personel_tel = @mysql_real_escape_string(post("personel_tel"));

    if ($personel_TC == "") {
        echo '<br><br><br><br><br><br><br><br><br>';
        //mesajUyari('' , 'Personel TC\'sini boş bırakmayınız...');
    } else {
        if (@get("islem") == "Ekle") {
            $Ekle = Sor("INSERT INTO personeller SET "
                    . "personel_TC='{$personel_TC}',"
                    . "kullanici_adi='{$kullanici_adi}',"
                    . "sifre='{$sifre}',"
                    . "personel_adi='{$personel_adi}',"
                    . "personel_soyadi='{$personel_soyadi}',"
                    . "dogum_tarihi='{$dogum_tarihi}',"
                    . "personel_cinsiyet='{$personel_cinsiyet}', "
                    . "personel_adres='{$personel_adres}',"
                    . "personel_il='{$personel_il}',"
                    . "personel_ilce='{$personel_ilce}',"
                    . "personel_tel='{$personel_tel}' 
				  ");



            if ($Ekle) {
                echo "<br><br><br><br><br><br><br><br><br>";
                //mesajUyari('ok' , 'Başarılı');
            } else {
                echo "<br><br><br><br><br><br><br><br><br>";
                //mesajUyari('' , 'Yapılamadı');
            }
        } else if (@get("islem") == "Guncelle") {
            $Guncelle = Sor("UPDATE personeller SET "
                    . "personel_TC='{$personel_TC}',"
                    . "kullanici_adi='{$kullanici_adi}',"
                    . "sifre='{$sifre}',"
                    . "personel_adi='{$personel_adi}',"
                    . "personel_soyadi='{$personel_soyadi}',"
                    . "dogum_tarihi='{$dogum_tarihi}',"
                    . "personel_cinsiyet='{$personel_cinsiyet}', "
                    . "personel_adres='{$personel_adres}',"
                    . "personel_ilce='{$personel_ilce}',"
                    . "personel_tel='{$personel_tel}', "
                    . "personel_tel='{$personel_tel}'  "
                    . "WHERE ID='" . @get("ID") . "' ");



            if ($Guncelle) {
                echo "<br><br><br><br><br><br><br><br><br>";
                // mesajUyari('ok' , 'Başarılı');
            } else {
                echo "<br><br><br><br><br><br><br><br><br>";
                //mesajUyari('' , 'Yapılamadı');
            }
        }
    }
}

$num = $_POST['num'];
$isme = $_POST['isme'];
$soyisme = $_POST['soyisme'];
$tcye = $_POST['tcye'];
$secilencombo = $_POST["combo"];
$secilenradio = $_POST['optradio'];

$KatSor = Sor("SELECT * FROM personeller ORDER BY ID ASC");

if (isset($_POST['kriter'])) {
    $sira = "";
    if ($secilenradio == "artan")
        $sira = "ASC";
    else
        $sira = "DESC";

    $KatSor = Sor("SELECT * FROM personeller ORDER BY " . $secilencombo . " " . $sira);
}


if (isset($_POST['say'])) {
    $KatSor = Sor("SELECT * FROM personeller ORDER BY ID ASC LIMIT 0, " . $num);
}


if (isset($_POST['adkriter'])) {
    $KatSor = Sor("SELECT * FROM personeller WHERE personel_adi='" . $isme . "' and personel_soyadi='" . $soyisme . "'");
}

if (isset($_POST['tcYe'])) {
    $KatSor = Sor("SELECT * FROM personeller WHERE personel_TC='" . $tcye . "'");
}


if (isset($_POST['tum'])) {
    $KatSor = Sor("select * from personeller where personel_adi='" . $isme . "' and personel_soyadi='" . $soyisme . "' and personel_TC='" . $tcye . "' 
	ORDER BY ID ASC LIMIT 0, " . $num);
}


$where = array();
$where2 = array();
if ($_POST['isme']) {
    $isim = $_POST['isme'];
    array_push($where, "personel_adi='" . $isim . "'");
}
if ($_POST['soyisme']) {
    $syisim = $_POST['soyisme'];
    array_push($where, "personel_soyadi='" . $syisim . "'");
}
if ($_POST['tcye']) {
    $tcye = $_POST['tcye'];
    array_push($where, "personel_TC='" . $tcye . "'");
}



if ($_POST['optradio']) {
    $secilenradio = $_POST['optradio'];

    $secilencombo = $_POST["combo"];
    $sira = "";
    if ($secilenradio == "artan") {
        $sira = "ASC";
        array_push($where2, " ORDER BY " . $secilencombo . " " . $sira);
    } else {

        $sira = "DESC";
        array_push($where2, " ORDER BY " . $secilencombo . " " . $sira);
    }
}
if ($_POST['num']) {
    $num = $_POST['num'];
    array_push($where2, " LIMIT 0, " . $num);
}

if ($_POST['tum']) {
    $srg = implode(" AND ", $where);
    $srg2 = implode(" ", $where2);
    $KatSor = Sor("select * from personeller where " . $srg . " " . $srg2);
}
?>
</br></br></br></br></br></br></br></br></br></br>
<div class="content-box ">

    <div class="content-box-header"> <!-- Add the class "closed" to the Content box header to have it closed by default -->

        <h3>Personel Listesi</h3>

    </div> <!-- End .content-box-header -->

    <div class="content-box-content">

        <div class="tab-content default-tab">
<?php
if ((@get("islem") == "Duzenle" || @get("islem") == "Guncelle" ) AND @ get("ID") != "") {
    $OgrDuzenleSor = Sor("SELECT * FROM personeller WHERE ID='" . @get("ID") . "'");
    if (Sar($OgrDuzenleSor) > 0) {
        $OgrDuzenleYaz = Yaz($OgrDuzenleSor);
        ?>


                    <form action="index.php?Go=Personel&islem=Guncelle&ID=<?php echo get("ID"); ?>" method="POST">

                        <fieldset>
                            <table class="table">

                                <tr>
                                    <td class="TableBaslik">Personel TC</td>
                                    <td class="TableContent"><input type="text" id="personel_TC" name="personel_TC" class="text-input large-input FontSize_13" value="<?php echo @post("personel_TC") != "" ? @post("personel_TC") : $OgrDuzenleYaz["personel_TC"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Kullanıcı adı</td>
                                    <td class="TableContent"><input type="text" id="kullanici_adi" name="kullanici_adi" class="text-input large-input FontSize_13" value="<?php echo @post("personel_adi") != "" ? @post("personel_adi") : $OgrDuzenleYaz["personel_adi"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Şifre</td>
                                    <td class="TableContent"><input type="text" id="sifre" name="sifre" class="text-input large-input FontSize_13" value="<?php echo @post("sifre") != "" ? @post("sifre") : $OgrDuzenleYaz["sifre"]; ?>" /></td>
                                </tr>


                                <tr>
                                    <td class="TableBaslik">Personel Adı</td>
                                    <td class="TableContent"><input type="text" id="personel_adi" name="personel_adi" class="text-input large-input FontSize_13" value="<?php echo @post("personel_adi") != "" ? @post("personel_adi") : $OgrDuzenleYaz["personel_adi"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Personel Soyadı</td>
                                    <td class="TableContent"><input type="text" id="personel_soyadi" name="personel_soyadi" class="text-input large-input FontSize_13" value="<?php echo @post("personel_soyadi") != "" ? @post("personel_soyadi") : $OgrDuzenleYaz["personel_soyadi"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Personel Doğum Tarihi</td>
                                    <td class="TableContent"><input type="date" id="dogum_tarihi" name="dogum_tarihi" class="text-input large-input FontSize_13" value="<?php echo @post("dogum_tarihi") != "" ? @post("dogum_tarihi") : $OgrDuzenleYaz["dogum_tarihi"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Personel Cinsiyeti</td>
                                    <td class="TableContent"><input type="text" id="personel_cinsiyet" name="personel_cinsiyet" class="text-input large-input FontSize_13" value="<?php echo @post("personel_cinsiyet") != "" ? @post("personel_cinsiyet") : $OgrDuzenleYaz["personel_cinsiyet"]; ?>" /></td>
                                </tr>


                                <tr>
                                    <td class="TableBaslik">personel Adres</td>
                                    <td class="TableContent"><input type="text" id="personel_adres" name="personel_adres" class="text-input large-input FontSize_13" value="<?php echo @post("personel_adres") != "" ? @post("personel_adres") : $OgrDuzenleYaz["personel_adres"]; ?>" /></td>
                                </tr>
                                <tr>
                                    <td class="TableBaslik">İl</td>
                                    <td class="TableContent"><input type="text" id="personel_il" name="personel_il" class="text-input large-input FontSize_13" value="<?php echo @post("personel_il") != "" ? @post("personel_il") : $OgrDuzenleYaz["personel_il"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">İlçe</td>
                                    <td class="TableContent"><input type="text" id="personel_ilce" name="personel_ilce" class="text-input large-input FontSize_13" value="<?php echo @post("personel_ilce") != "" ? @post("personel_ilce") : $OgrDuzenleYaz["personel_ilce"]; ?>" /></td>
                                </tr>
                                <tr>
                                    <td class="TableBaslik">Telefon1</td>
                                    <td class="TableContent"><input type="text" id="personel_tel" name="personel_tel" class="text-input large-input FontSize_13" value="<?php echo @post("personel_tel") != "" ? @post("personel_tel") : $OgrDuzenleYaz["personel_tel"]; ?>" /></td>
                                </tr>



                                <tr>
                                    <td class="TableBaslik"></td>
                                    <td class="TableContent"><input type="submit" id="kaydet" name="kaydet" class="button MarginR_15 FontSize_15" value="Kaydet" />
                                <a href="index.php?Go=Personel" class="remove-link FontSize_14">iptal et </a></td>
                                </tr>


                            </table>
                        </fieldset>

                    </form>



        <?php
    } else {
        mesajUyari('', 'Böyle bir kayıt yok');
    }
} else if (@get("islem") == "") {
    ?>

                <form action="index.php?Go=Personel&islem=Ekle" method="POST">

                    <fieldset>
                        <table class="table">


                            <tr>
                                <td class="TableBaslik">Personel TC</td>
                                <td class="TableContent"><input type="text" placeholder="personel TC..." id="personel_TC" name="personel_TC" class="text-input large-input FontSize_13" value="<?php echo @post("personel_TC") != "" ? @post("personel_TC") : null; ?>" /></td>
                            </tr>

                            <tr>
                                <td class="TableBaslik">kullanıcı Adı</td>
                                <td class="TableContent"><input type="text" placeholder="personel kullanıcı adı..." id="kullanici_adi" name="kullanici_adi" class="text-input large-input FontSize_13" value="<?php echo @post("personel_soyadi") != "" ? @post("personel_soyadi") : null; ?>" /></td>
                            </tr>

                            <tr>
                                <td class="TableBaslik">Şifre</td>
                                <td class="TableContent"><input type="text" placeholder="personel kullanıcı şifresi..." id="sifre" name="sifre" class="text-input large-input FontSize_13" value="<?php echo @post("dogum_tarihi") != "" ? @post("dogum_tarihi") : null; ?>" /></td>
                            </tr>

                            <tr>
                                <td class="TableBaslik">Personel Adı</td>
                                <td class="TableContent"><input type="text" placeholder="personel adı..." id="personel_adi" name="personel_adi" class="text-input large-input FontSize_13" value="<?php echo @post("personel_adi") != "" ? @post("personel_adi") : null; ?>" /></td>
                            </tr>

                            <tr>
                                <td class="TableBaslik">Personel Soyadı</td>
                                <td class="TableContent"><input type="text" placeholder="personel soyadı..." id="personel_soyadi" name="personel_soyadi" class="text-input large-input FontSize_13" value="<?php echo @post("personel_soyadi") != "" ? @post("personel_soyadi") : null; ?>" /></td>
                            </tr>

                            <tr>
                                <td class="TableBaslik">Personel Doğum Tarihi</td>
                                <td class="TableContent"><input type="date" placeholder="personel doğum tarihi..." id="dogum_tarihi" name="dogum_tarihi" class="text-input large-input FontSize_13" value="<?php echo @post("dogum_tarihi") != "" ? @post("dogum_tarihi") : null; ?>" /></td>
                            </tr>

                            <tr>
                                <td class="TableBaslik">Personel Cinsiyeti</td>
                                <td class="TableContent"><input type="text" placeholder="personel cinsiyeti..." id="personel_cinsiyet" name="personel_cinsiyet" class="text-input large-input FontSize_13" value="<?php echo @post("personel_cinsiyet") != "" ? @post("personel_cinsiyet") : null; ?>" /></td>
                            </tr>


                            <tr>
                                <td class="TableBaslik">personel Adres</td>
                                <td class="TableContent"><input type="text" placeholder="personel adresi..." id="personel_adres" name="personel_adres" class="text-input large-input FontSize_13" value="<?php echo @post("personel_adres") != "" ? @post("personel_adres") : null; ?>" /></td>
                            </tr>
                            <tr>
                                <td class="TableBaslik">İl</td>
                                <td class="TableContent"><input type="text" placeholder="bulunduğu il..." id="personel_il" name="personel_il" class="text-input large-input FontSize_13" value="<?php echo @post("personel_il") != "" ? @post("personel_il") : null; ?>" /></td>
                            </tr>

                            <tr>
                                <td class="TableBaslik">İlçe</td>
                                <td class="TableContent"><input type="text" placeholder="bulunduğu ilçe..." id="personel_ilce" name="personel_ilce" class="text-input large-input FontSize_13" value="<?php echo @post("personel_ilce") != "" ? @post("personel_ilce") : null; ?>" /></td>
                            </tr>
                            <tr>
                                <td class="TableBaslik">Telefon1</td>
                                <td class="TableContent"><input type="text" placeholder="personel CEP telefonı..." id="personel_tel" name="personel_tel" class="text-input large-input FontSize_13" value="<?php echo @post("personel_tel") != "" ? @post("personel_tel") : null; ?>" /></td>
                            </tr>




                            <tr>
                                <td class="TableBaslik"></td>
                                <td class="TableContent"><input type="submit" id="kaydet" name="kaydet" class="button MarginR_15 FontSize_15" value="Kaydet" />
                            <a href="index.php?Go=Personel" class="remove-link FontSize_14">iptal et </a></td>
                            </tr>



                        </table>
                    </fieldset>

                </form>
<?php } ?>
        </div> <!-- End #tab3 -->        

    </div> <!-- End .content-box-content -->
    <div class="content-box-content">

        <div class="tab-content default-tab">

<?php
if (@Sar($KatSor) > 0) {
    echo '<table class="table">'
    . '<tr>'
    . '<td style="width:25px;text-align:center;">NO</td>'
    . '<td>personel_TC</td>'
    . '<td>kullanici_adi</td>'
    . '<td>sifre</td>'
    . '<td>personel_adi</td>'
    . '<td>personel_soyadi</td>'
    . '<td>dogum_tarihi</td>'
    . '<td>personel_cinsiyet</td>'
    . '<td>personel_adres</td>'
    . '<td>personel_il</td>'
    . '<td>personel_ilce</td>'
    . '<td>personel_tel</td>'
    . '<td style="text-align:center;">Kontroller</td>'
    . '</tr>';
    while ($Yaz = @Yaz($KatSor)) {
        echo '<tr>'
        . '<td style="text-align:center;">' . $Yaz["ID"] . '</td>'
        . '<td style="text-align:center;">' . $Yaz["personel_TC"] . '</td>'
        . '<td style="text-align:left;">' . $Yaz["personel_adi"] . '</td>'
        . '<td style="text-align:center;">' . $Yaz["sifre"] . '</td>'
        . '<td style="text-align:left;">' . $Yaz["personel_adi"] . '</td>'
        . '<td style="text-align:left;">' . $Yaz["personel_soyadi"] . '</td>'
        . '<td style="text-align:left;">' . $Yaz["dogum_tarihi"] . '</td>'
        . '<td style="text-align:left;">' . $Yaz["personel_cinsiyet"] . '</td>'
        . '<td style="text-align:left;">' . $Yaz["personel_adres"] . '</td>'
        . '<td style="text-align:left;">' . $Yaz["personel_il"] . '</td>'
        . '<td style="text-align:left;">' . $Yaz["personel_ilce"] . '</td>'
        . '<td style="text-align:left;">' . $Yaz["personel_tel"] . '</td>'
        . '<td style="text-align:center;">'
        . '<a href="index.php?Go=Personel&islem=Duzenle&ID=' . $Yaz["ID"] . '" title="Düzenle">Düzenle</a> | '
        . '<a href="index.php?Go=Personel&islem=sil&ID=' . $Yaz["ID"] . '" title="sil" style="color:darkred;" onclick="return confirm(\'Silmek İstediğinize Eminmisniz\')">sil</a>'
        . '</td>'
        . '</tr>';
    }
    echo '</table>';
} else {
    echo 'Kayıt Bulunamadı.';
}
?>

        </div>
    </div>    
</div>


