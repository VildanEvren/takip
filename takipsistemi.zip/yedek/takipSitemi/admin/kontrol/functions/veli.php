﻿<?php
include "baglan.php";




$site_iletisim = mysql_fetch_array(mysql_query("select *from site_iletisim where ID ='1'"));
$Tel[1] = $site_iletisim['Tel'];
$Fax[1] = $site_iletisim['Fax'];
$Adres[1] = $site_iletisim['Adres'];
$Ilce[1] = $site_iletisim['Ilce'];
$Il[1] = $site_iletisim['Il'];
$Mail[1] = $site_iletisim['Mail'];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Ana Sayfa</title>
        <style type="text/css">
            .img-bir,.img-iki,.img-uc,.img-dort,.img-bes{
                position:absolute;
                height: 250px;
                width: 980px;
            }

            .img-bir{left:0px;}
            .img-iki{left:980px;}
            .img-uc{left:1960px;}
            .img-dort{left:2940px;}
            .img-bes{left:3920px;}

            #banner > .slider{
                position:absolute;
                left:0px;
                width: 3920px;
                height: 250px;
                -webkit-animation-name:sliders;
                -webkit-animation-duration:20s;
                -webkit-animation-iteration-count:infinite;
            }

            #banner > .slider:hover{
                -webkit-animation-play-state:paused;
            }

            @-webkit-keyframes sliders{
                0%{left:0px;}
                10%{left:0px;}
                20%{left:-980px;}
                30%{left:-980px;}
                40%{left:-1960px;}
                50%{left:-1960px;}
                60%{left:-2940px;}
                70%{left:-2940px;}

            }
            #uyeKaydi {
                height: 265px;
                width: 400px;
                margin-top: 5px;
                background-image: url(resimler/images.png);
                background-repeat: repeat-y;
            }
        </style>
        <link href="sinif.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            body,td,th {
                font-family: "Comic Sans MS", cursive;
            }
            #iletisim {
                height: 50px;
                width: 980px;
            }
            #iletisimIcerik {
                height: 450px;
                width: 980px;
                background-image: url(resimler/Doku%20Arka%20Plan%20-%20Background.png);
            }
            #iletisimsol {
                float: left;
                height: 500px;
                width: 490px;
            }
        </style>
    </head>
    <body>

        <div id="container">
            <div id="header">
                <div id="logo"><img src="resimler/indir.jpg" width="185" height="149" /></div>
                <div id="menu">
                    <ul>
                        <li><a href="anasayfa.php">Ana Sayfa</a></li>
                        <li><a href="etkinlikOrnekleri.php">Hakkımızda</a></li>
                        <li><a href="sinif.php">Sınıflar</a></li>
                        <li><a href="etkinlikPlanlari.php">Planlar</a></li>
                        <li><a href="bizeUlasin.php">Bize Ulaşın</a></li>
                    </ul>
                </div>
            </div>
            <div id="clear-header"></div>
            <div id="banner">
                <a href="" class="img-bir"> <img src="resim/l.jpg" width="980" height="250" alt=""/> </a> 
            </div>
            <div id="cizgi"><img src="resimler/cizgi.png" width="980" height="14" /></div>
            <div id="iletisim"> id "iletisim" İçeriği Buraya Gelecek</div>
            <div id="iletisimIcerik">
                <div id="iletisimsol">
                    <p>
                        <?php
                        echo "Telefon1:" . $Tel[1] . "<br><br>
	Fax:" . $Fax[1] . "<br>";
                        ?>
                    </p>

                </div>
            </div>
        </div>
        </div>
    </body>
</html>