<div class="content-box column-left">

    <div class="content-box-header">

        <h3>Personel Takip sitemi</h3>

    </div> 

    <div class="content-box-content">

        <div class="tab-content default-tab">
            <p>Personellerinizin konumlarını buradan öğrenebilirsiniz.</p>
        </div>       

    </div> 

</div> 

<div class="content-box column-right">

    <div class="content-box-header">

        <h3>Not</h3>

    </div> 


    <div class="content-box-content">

        <div class="tab-content default-tab">
            <p>...</p>
        </div> 
    </div> 		
</div>
<div class="clear"></div>