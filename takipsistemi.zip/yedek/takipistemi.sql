-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Anamakine: localhost
-- Üretim Zamanı: 02 Temmuz 2016 saat 18:48:54
-- Sunucu sürümü: 5.1.41
-- PHP Sürümü: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `takipistemi`
--

-- --------------------------------------------------------

--
-- Tablo yapısı: `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci AUTO_INCREMENT=2 ;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`ID`, `username`, `password`, `name`, `email`) VALUES
(1, 'Vildan', '12345', 'Vildan Evren', 'evren@gmail.com');

-- --------------------------------------------------------

--
-- Tablo yapısı: `konum`
--

CREATE TABLE IF NOT EXISTS `konum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Personel` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `enlem` varchar(25) COLLATE utf8_turkish_ci NOT NULL,
  `boylam` varchar(25) COLLATE utf8_turkish_ci NOT NULL,
  `tarih` date NOT NULL,
  `saat` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci AUTO_INCREMENT=26 ;

--
-- Tablo döküm verisi `konum`
--

INSERT INTO `konum` (`id`, `Personel`, `enlem`, `boylam`, `tarih`, `saat`) VALUES
(1, 'Veli', '37.9740555', '32.5202908', '2016-06-27', '14:56'),
(2, 'Mehmet', '37.9740555', '32.5202908', '2016-06-27', '14:56'),
(3, 'Demet', '37.9740555', '32.5202908', '2016-06-27', '14:58'),
(4, 'Miray', '37.9740555', '32.5202908', '2016-06-27', '14:59'),
(5, 'Ali', '37.9740555', '32.5202908', '2016-06-27', '14:59'),
(6, 'Miray', '37.9740555', '32.5202908', '2016-06-27', '16:29'),
(7, 'Miray', '37.9740555', '32.5202908', '2016-06-27', '16:46'),
(8, 'Veli', '37.9740555', '32.5202908', '2016-06-27', '16:46'),
(9, 'Ali', '37.9740555', '32.5202908', '2016-06-28', '08:53'),
(10, 'ali', '37.9740555', '32.5202908', '2016-06-28', '18:13'),
(11, 'ali', '37.9740555', '32.5202908', '2016-06-28', '18:15'),
(12, 'ali', '37.9740555', '32.5202908', '2016-06-28', '18:16'),
(13, 'Ali', '37.9740555', '32.5202908', '2016-06-29', '12:11'),
(25, 'Ahmet', '37.9667643', '32.5075157', '2016-07-02', '13:51'),
(24, 'Ahmet', '37.9667643', '32.5075157', '2016-07-02', '12:17');

-- --------------------------------------------------------

--
-- Tablo yapısı: `personeller`
--

CREATE TABLE IF NOT EXISTS `personeller` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `personel_TC` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `personel_adi` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `personel_soyadi` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `dogum_tarihi` date NOT NULL,
  `personel_cinsiyet` varchar(6) COLLATE utf8_turkish_ci NOT NULL,
  `personel_adres` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `personel_il` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `personel_ilce` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `personel_tel` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `kullanici_adi` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `sifre` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci AUTO_INCREMENT=11 ;

--
-- Tablo döküm verisi `personeller`
--

INSERT INTO `personeller` (`ID`, `personel_TC`, `personel_adi`, `personel_soyadi`, `dogum_tarihi`, `personel_cinsiyet`, `personel_adres`, `personel_il`, `personel_ilce`, `personel_tel`, `kullanici_adi`, `sifre`) VALUES
(1, '62251031875', 'Veli', 'evren', '1960-05-02', 'Bay', 'Şişli', 'Istanbul', 'Şişli', '0534 987 65 22', 'Veli', '147'),
(2, '78965412589', 'Mehmet', 'Demir', '1968-06-10', 'Bay', 'Kağıthane', '', 'Kağıthane', '0534 789 54 62', 'Mehmet', '789'),
(3, '12347895478', 'Demet', 'Enez', '1960-06-16', 'Bayan', 'Şişli', 'Istanbul', 'Şişli', '0534 987 65 78', 'Demet', '789'),
(4, '98854721069', 'Miray', 'Kaya', '1978-01-07', 'Bayan', 'Kağıthane', 'Istanbul', 'Kağıthane', '0534 789 54 60', 'Miray', 'Kaya'),
(5, '68954784120', 'Ali', 'Çelik', '1968-06-15', 'Bay', 'Kağıthane', 'Istanbul', 'Kağıthane', '0534 987 65 44', 'Ali', '14'),
(6, '63354121029', 'Veli', 'Adaş', '1968-06-21', 'Bay', 'Şişli', 'Istanbul', 'Şişli', '0534 987 65 29', 'Veli', 'asd12'),
(9, '68879421850', 'Ahmet', 'Kaya', '1962-06-23', 'Bay', 'Kağıthane', '', 'Kağıthane', '0534 987 65 10', 'Ahmet', '622510'),
(10, '62254123102', '', 'Evren', '1975-07-01', 'Bay', 'Kağıthane', 'Istanbul', 'Kağıthane', '0534 987 65 30', 'vildan', 'Evren');

-- --------------------------------------------------------

--
-- Tablo yapısı: `uyeler`
--

CREATE TABLE IF NOT EXISTS `uyeler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kullanici_adi` varchar(30) COLLATE utf8_turkish_ci NOT NULL,
  `sifre` varchar(30) COLLATE utf8_turkish_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci AUTO_INCREMENT=6 ;

--
-- Tablo döküm verisi `uyeler`
--

INSERT INTO `uyeler` (`id`, `kullanici_adi`, `sifre`, `email`) VALUES
(1, 'Vildan', 'vildan', 'evrenvildannn@gmail.com'),
(2, 'Fatih', 'fatih', 'fatih@gmail.com'),
(3, 'Mehmet', 'mehmet', 'mehmet@gmail.com'),
(4, 'Demet', 'demet', 'demet@gmail.com'),
(5, 'Kerim', 'kerim', 'kerim@gmail.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
