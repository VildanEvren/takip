

<?php
Connect();
if (@get("islem") == "sil") {
    $sil = Sor("DELETE FROM konum WHERE id='" . @get("id") . "'");
}
if (@$_POST) {
    $Personel = @mysql_real_escape_string(post("Personel"));
    $enlem = @mysql_real_escape_string(post("enlem"));
    $boylam = @mysql_real_escape_string(post("boylam"));
    $tarih = @mysql_real_escape_string(post("tarih"));
    $saat = @mysql_real_escape_string(post("saat"));

    if ($Personel == "") {
        echo '<br><br><br><br><br><br><br><br><br>';
        //mesajUyari('' , 'Personel TC\'sini bo� b�rakmay�n�z...');
    } else {
        if (@get("islem") == "Ekle") {
            $Ekle = Sor("INSERT INTO konum SET "
                    . "Personel='{$Personel}',"
                    . "enlem='{$enlem}',"
                    . "boylam='{$boylam}',"
                    . "tarih='{$tarih}',"
                    . "saat='{$saat}'
				  ");



            if ($Ekle) {
                echo "<br><br><br><br><br><br><br><br><br>";
                mesajUyari('ok', 'Ba�ar�l�');
            } else {
                echo "<br><br><br><br><br><br><br><br><br>";
                mesajUyari('', 'Yap�lamad�');
            }
        } else if (@get("islem") == "Guncelle") {
            $Guncelle = Sor("UPDATE konum SET "
                    . "Personel='{$Personel}',"
                    . "enlem='{$enlem}',"
                    . "boylam='{$boylam}',"
                    . "tarih='{$tarih}',"
                    . "saat='{$saat}' "
                    . "WHERE id='" . @get("id") . "' ");



            if ($Guncelle) {
                echo "<br><br><br><br><br><br><br><br><br>";
                mesajUyari('ok', 'Ba�ar�l�');
            } else {
                echo "<br><br><br><br><br><br><br><br><br>";
                mesajUyari('', 'Yap�lamad�');
            }
        }
    }
}

$secilencombo = $_POST['combo'];
$secilenradio = $_POST['optradio'];
$girilenisim = $_POST['isme'];
$girilentarih = $_POST['tarih1'];
$bitistarih = $_POST['tarih2'];
$alann1 = $_POST['alan1'];
$alann2 = $_POST['alan2'];
$num = $_POST['num'];

$KatSor = Sor("SELECT * FROM konum ORDER BY id ASC");

if (isset($_POST['kriter'])) {
    $sira = "";
    if ($secilenradio == "artan")
        $sira = "ASC";
    else
        $sira = "DESC";

    $KatSor = Sor("SELECT * FROM konum ORDER BY " . $secilencombo . " " . $sira);
}

if (isset($_POST['adkriter'])) {
    $KatSor = Sor("SELECT * FROM konum WHERE Personel='" . $girilenisim . "'");
}


if (isset($_POST['tarihkriter'])) {
    $KatSor = Sor("SELECT * FROM konum where tarih between \"" . $girilentarih . "\" and \"" . $bitistarih . "\"");
}


if (isset($_POST['tkriter'])) {
    $KatSor = Sor("SELECT * FROM konum WHERE Personel='" . $alann1 . "' and saat='" . $alann2 . "'");
}


if (isset($_POST['say'])) {
    $KatSor = Sor("SELECT * FROM konum ORDER BY id ASC LIMIT 0, " . $num);
}




if(isset($_POST['adkriter']))
{
if($_POST['combo1'])
{
	$secilencombo1 = $_POST["combo1"];
	$girilenisim = $_POST['isme'];
	
	
	if($secilencombo1== 'LIKE %'){
		$KatSor = Sor("SELECT * FROM konum  where Personel LIKE '".$girilenisim."%' ");
		}
	
	else if($secilencombo1== 'NOT LIKE %'){
		$KatSor = Sor("SELECT * FROM konum  where Personel NOT LIKE '".$girilenisim."%' ");
		}
		
		else if($secilencombo1== 'LIKE %%'){
		$KatSor = Sor("SELECT * FROM konum  where Personel  LIKE '%".$girilenisim."%' ");
		}
		
		else if($secilencombo1== 'NOT LIKE %%'){
		$KatSor = Sor("SELECT * FROM konum  where Personel NOT LIKE '%".$girilenisim."%' ");
		}
		
	    else if($secilencombo1== '>'){
		$KatSor = Sor("SELECT * FROM konum  ORDER BY Personel ASC");
		}
		else if($secilencombo1== '<'){
		$KatSor = Sor("SELECT * FROM konum  ORDER BY Personel DESC");
		}
		
}
}


?>
</br></br></br></br></br></br></br></br></br></br>
<div class="content-box ">

    <div class="content-box-header"> <!-- Add the class "closed" to the Content box header to have it closed by default -->

        <h3>Personel Konum Listesi</h3>

    </div> <!-- End .content-box-header -->

    <div class="content-box-content">

        <div class="tab-content default-tab">
<?php
if ((@get("islem") == "Duzenle" || @get("islem") == "Guncelle" ) AND @ get("id") != "") {
    $OgrDuzenleSor = Sor("SELECT * FROM konum WHERE id='" . @get("id") . "'");
    if (Sar($OgrDuzenleSor) > 0) {
        $OgrDuzenleYaz = Yaz($OgrDuzenleSor);
        ?>


                    <form action="index.php?Go=konumFiltre&islem=Guncelle&id=<?php echo get("id"); ?>" method="POST">

                        <fieldset>
                            <table class="table">

                                <tr>
                                    <td class="TableBaslik" >Personel Ad</td>
                                    <td class="TableContent">
                                <input type="text" id="Personel" name="Personel" class="text-input large-input FontSize_13" value="<?php echo @post("Personel") != "" ? @post("Personel") : $OgrDuzenleYaz["Personel"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Enlem</td>
                                    <td class="TableContent"><input type="text" id="enlem" name="enlem" class="text-input large-input FontSize_13" value="<?php echo @post("enlem") != "" ? @post("enlem") : $OgrDuzenleYaz["enlem"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Boylam</td>
                                    <td class="TableContent"><input type="text" id="boylam" name="boylam" class="text-input large-input FontSize_13" value="<?php echo @post("boylam") != "" ? @post("boylam") : $OgrDuzenleYaz["boylam"]; ?>" /></td>
                                </tr>



                                <tr>
                                    <td class="TableBaslik">Tarih</td>
                                    <td class="TableContent"><input type="date" id="tarih" name="tarih" class="text-input large-input FontSize_13" value="<?php echo @post("tarih") != "" ? @post("tarih") : $OgrDuzenleYaz["tarih"]; ?>" /></td>
                                </tr>

                                <tr>
                                    <td class="TableBaslik">Saat</td>
                                    <td class="TableContent"><input type="text" id="saat" name="saat" class="text-input large-input FontSize_13" value="<?php echo @post("saat") != "" ? @post("saat") : $OgrDuzenleYaz["saat"]; ?>" /></td>
                                </tr>


                                <tr>
                                    <td class="TableBaslik"></td>
                                    <td class="TableContent"><input type="submit" id="kaydet" name="kaydet" class="button MarginR_15 FontSize_15" value="Kaydet" />
                                <a href="index.php?Go=konumFiltre" class="remove-link FontSize_14">iptal et </a></td>
                                </tr>



                            </table>
                        </fieldset>

                    </form>



        <?php
    } else {
        mesajUyari('', 'B�yle bir kay�t yok');
    }
} else if (@get("islem") == "") {
    ?>

                <form action="index.php?Go=konumFiltre&islem=Ekle" method="POST">

                    <fieldset>
                        <table class="table">
                            <tr> 
                                <td style="width:15%">Siralama Kriterleri</td>
                                <td>
                                    <table>
                                        <tbody>
                                            <tr>
                                                <td style="width:10%"><select class="text-input Default-input"  data-style="btn-primary" class="selectpicker" data-live-search="true" name="combo">
                                                        <option>siralama kriteri sec</option>
                                                        <option>id</option>
                                                        <option>enlem</option>
                                                        <option>boylam</option>
                                                        <option>tarih</option>
                                                        <option>saat</option>
                                                    </select>

                                                    <label><br><input type="radio" id="az" name="optradio" value="azalan">Azalan Sirada</label>
                                                    <label><input type="radio" name="optradio" value="artan">Artan Sirada</label>
                                        <input type="submit" id="kriter" name="kriter" value="Kritere gore sirala" /></td>
                                </td>

                                <td>
                                    <table>
                                        <tr>
                                            <td>Bas. tarihi:&nbsp;<input  type="date" class="text-input Default-input" id="tarih1" name="tarih1" ></td>
                                            </tr>
                                            <tr>
                                                <td>Bit. tarihi:&nbsp;&nbsp;&nbsp;<input  type="date" class="text-input Default-input" id="tarih2" name="tarih2"></td>
                                                </tr>
                                                <tr>
                                                    <td>

                                                <center><input type="submit" id="tarihkriter" name="tarihkriter"  value="Tarihe gore sirala" /></center>

                                                </td>
                                                </tr>
                                                </table>
                                                </td>

                                                <td>
                                                    <table>
                                                        <tr>
                                                            <td> Kayit sayisi giriniz
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td> 
                                                                Kayit sayisi:<input type="number" class="text-input Default-input" min="0" max="20" value="0" class="form-control bfh-number" name="num"></td>
                                                            </tr>

                                                            <tr>
                                                                <td>
                                                                    <br>
                                                            <input type="submit" id="say" name="say"  value="Kayit goster" />
                                                            </td>
                                                            </tr>
                                                    </table>
                                                </td>
                                                <td>
                                                    </tr>
                                                    </tbody>
                                                    </table>		

                                                </td>
                                                </tr>


                                                <tr>
                                                    <td>Isme gore filtrele : </td>
                                                    <td>
                                                        <table>
                                                            <tbody>
                                                            <th style="width:20%">
                                                            <input  type="text" id="isme" class="text-input Default-input" placeholder="personel ismine gore..." name="isme">
                                                                
																
																</th>
																
																<td>
																 <select data-style="btn-primary" class="selectpicker" data-live-search="true" name="combo1">
                                              
                                                <option><</option>
                                                <option>></option>
                                                <option>LIKE %</option>
												 <option>NOT LIKE %</option>
                                                <option>LIKE %%</option>
                                                <option>NOT LIKE %%</option>
                                                

                                            </select>
																
																<input type="submit" id="adkriter" name="adkriter" class="button MarginR_15 FontSize_15" value="Isme gore" />

																</td>
																
																
                                                        </table>
                                                    </td>
                                                </tr>


                                                </table>
                                                </fieldset>
                                                </form>


<?php } ?>
                                            </div> <!-- End #tab3 -->        

                                            </div> <!-- End .content-box-content -->
                                            <div class="content-box-content">

                                                <div class="tab-content default-tab">

<?php
if ($_POST['adkriter'] || $_POST['say'] || $_POST['tarihkriter'] || $_POST['kriter']) {
    if (@Sar($KatSor) > 0) {
        echo '<table class="table">'
        . '<tr>'
        . '<td style="width:25px;text-align:center;">NO</td>'
        . '<td>Personel</td>'
        . '<td>enlem</td>'
        . '<td>boylam</td>'
        . '<td>tarih</td>'
        . '<td>saat</td>'
        . '<td style="text-align:center;">Kontroller</td>'
        . '</tr>';
        while ($Yaz = @Yaz($KatSor)) {
            echo '<tr>'
            . '<td style="text-align:center;">' . $Yaz["id"] . '</td>'
            . '<td style="text-align:center;">' . $Yaz["Personel"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["enlem"] . '</td>'
            . '<td style="text-align:center;">' . $Yaz["boylam"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["tarih"] . '</td>'
            . '<td style="text-align:left;">' . $Yaz["saat"] . '</td>'
            . '<td style="text-align:center;">'
            . '<a href="index.php?Go=konumFiltre&islem=Duzenle&id=' . $Yaz["id"] . '" title="D�zenle">Duzenle</a> | '
            . '<a href="index.php?Go=konumFiltre&islem=sil&id=' . $Yaz["id"] . '" title="sil" style="color:darkred;" onclick="return confirm(\'Silmek �stedi�inize Eminmisniz\')">sil</a>'
            . '</td>'
            . '</tr>';
        }
        echo '</table>';
    } else {
        echo 'Kayit Bulunamadi.';
    }
}
?>

                                                </div>
                                            </div>    
                                            </div>


